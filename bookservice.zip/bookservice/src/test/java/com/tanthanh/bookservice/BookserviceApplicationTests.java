package com.tanthanh.bookservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
